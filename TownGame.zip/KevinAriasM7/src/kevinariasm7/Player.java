 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kevinariasm7;

/**
 *
 * @author Admin
 */
public class Player {
    
public String name;
public Location location;
public Item[] inventory = new Item[3];
public int energy = 10;

public Player(){
    
}

public Player(String name){
    this.name = name;
}

}
