/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kevinariasm7;

/**
 *
 * @author Admin
 */
public class KevinAriasM7 {

    /**
     * @param args the command line arguments
     */
    
    //the strategy to win is to get the items from the town you spawn in
    //go the hashtown drop all items then go to nedtown get the items then go to edtown
    //pick the 2 items there go back to hashtown drop items there then go the final destination fredtown
    //to get the last two items
    
    public static void main(String[] args) {
      new GameWorld();
    }
   
}
