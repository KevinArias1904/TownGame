/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kevinariasm7;

/**
 *
 * @author Admin
 */
import java.util.ArrayList;
import java.util.Scanner;

public class GameWorld {
    public Location[] locations;
    public Player player = new Player();
    public Scanner scan = new Scanner(System.in);
    public String name;
    
public GameWorld(){      
    world();
    mainLoop();    
}    
    
public void world(){
    
    
       locations = new Location[6]; 
       locations[0] = new Location("KevTown", "It's a small town with small houses and nice people." + "\n" 
      + "There are some local stores you can stop and resupply." + "\n"
      + "People are outside just minding there own "+ "\n" + "buissnes cleaning and watering there garden.", 3, 3);
       locations[1] = new Location("NedTown", "This town there is a lot smaller but there are lovely people that would help you." + "\n"
            + "In this town there is a lot of sand more"+ "\n" + " landfields the smell of plants and grass.", 1, 1);
    
      locations[2] = new Location("JadeTown", "There isn't much in this town a couple of houses and stores."+ "\n"  
            + "The people here are nice people outside and enjoing the"+ "\n" + " day and weather always sunny fresh air.", 0, 1);
    
      locations[3] = new Location("HashTown", "Simple little town vendors outside couple of animals."+ "\n"
            + "The weather is always windy and cloudy the smell of the" + "\n " + " food vendors all kinds of food.", 1, 3);
    
      locations[4] = new Location("EdTown", "This town there are a lot more peopl more streat venders and more buildings." + "\n"
            + "There is a farm and there is lots of"+ "\n" + " animls horses, cows, goats and sheep", 2, 1);
    
      locations[5] = new Location("FredTown", "There is a path that takes straight into a market of vendors."+ "\n"
            + "The vendors try to sell you all kinds of stuff like armor equipment and food."+ "\n"
            + "you cross the market to end up in a village looking for an item.", 2, 1);
   
      //linking the locations they are adjacent to 
      locations[0].adjacentLocations.add(locations[1]);
      locations[0].adjacentLocations.add(locations[2]);
      locations[0].adjacentLocations.add(locations[3]);
      locations[1].adjacentLocations.add(locations[0]);
      locations[2].adjacentLocations.add(locations[0]);
      locations[3].adjacentLocations.add(locations[0]);
      locations[3].adjacentLocations.add(locations[4]);
      locations[3].adjacentLocations.add(locations[5]);
      locations[4].adjacentLocations.add(locations[3]);
      locations[5].adjacentLocations.add(locations[3]);
         
      Item horseShoe = new Item("Horse Shoe", "Old horse shoe could be sold for mony.");
      Item chain = new Item("Chain", "This chain could be helpful in someway.");
      Item barrel = new Item("Barrel", "This barrel could be use for carring water.");
      Item lamp = new Item("Lamp", "A lamp could help you travel at night.");
      Item umbrella = new Item("Umbrella", "Could be use on a town where its rainy.");
      Item hey = new Item("Hey", "Could be used for feeding your horse.");
      Item bread = new Item("Bread", "Bread Is good to eat.");
      Item cannedBeans = new Item("Canned Beans", "Beans are good and thats is their good.");
      Item greenLanternRing = new Item("Green Lantern Ring", "To bad it has no power and its lamp is nowhere to be seen.");
      
      locations[0].items.add(horseShoe);
      locations[0].items.add(chain);
      locations[0].items.add(barrel);
      locations[1].items.add(lamp);
      locations[3].items.add(umbrella);
      locations[4].items.add(hey);
      locations[4].items.add(bread);
      locations[5].items.add(cannedBeans);
      locations[5].items.add(greenLanternRing); 
     
    System.out.println("Welcome to Adventure World!");
    System.out.println("You will use the controls to move and pick up items.");
    System.out.println("You can carry only 3 items at a time.");
    System.out.println("You can press d (Drop) to drop items in the current location.");
    System.out.println("To win you have to collect all items and drop them of in");
    System.out.println("a single location. You have limited travels if you finish");
    System.out.println("all your travels before collecting all items you lose.");
    System.out.println("Now you will start in KevTown to begin your Adventure. Have Fun!");
    System.out.println("");
    System.out.println("****************************************************************");
    
    //this sets the spawning location
    player.location = locations[0];
}
    
public void mainLoop(){    

    
    System.out.println("Enter your name to get started: ");
    name = scan.nextLine();
   
    do{
    System.out.println("***********************************************");
    player.name = name;
    System.out.println(player.name + " your energy " + player.energy);
    player.location.display();
    int choice = scan.nextInt();
    if(choice == 1){
     ArrayList<Location> adjacentLocations = player.location.adjacentLocations;
     System.out.println("Select a town you will lose 1 energy.");
     for(int i = 0; i < adjacentLocations.size(); i++){
         System.out.println((i + 1) + ". " + adjacentLocations.get(i).name);
     }   
     int townChoice = scan.nextInt();
     if(townChoice > 0 && choice <= adjacentLocations.size()){
        player.location = adjacentLocations.get(townChoice - 1);
        player.energy--;
     }
     }else if(choice == 2){
      ArrayList<Item>items = player.location.items;
      System.out.println("");
      System.out.println("Select an item to pick up.");
      for(int i = 0; i < items.size(); i++){
         System.out.println((i + 1) + ". " + items.get(i).itemName);
     }int itemChoice = scan.nextInt();
       if(itemChoice > 0 && itemChoice <= items.size()){
          Item item = items.get(itemChoice - 1);
          
          if(player.inventory[0] == null){
              player.inventory[0] = item;
          }else if (player.inventory[1] == null){
              player.inventory[1] = item;
          }else if (player.inventory[2] == null){
              player.inventory[2] = item;
          }else{
              System.out.println("Inventory is full.");
          }
           items.remove(item);
           System.out.println("You Picked Up " + item.getItemName() + ".");
         }      
     }else if(choice == 3){
         Item[] inventory = player.inventory;
         System.out.println("Pick an item to drop.");
         for(int i = 0; i < player.inventory.length; i++){
          System.out.println((i + 1) + ". " + (inventory[i] != null ? inventory[i].getItemName() : "Empty"));  
         } 
         int dropChoice = scan.nextInt();
         if(dropChoice > 0 && dropChoice <= inventory.length){
            if(inventory[dropChoice - 1] != null){
             player.location.items.add(inventory[dropChoice - 1]);
             for(int i = 0; i < inventory.length; i++){
               if(inventory[dropChoice - 1] != null){
               inventory[dropChoice - 1] = null;
               }else{
                  System.out.println("Try Again."); 
               }  
               }                
                System.out.println("Item has been dropped.");
            }else{
                System.out.println("Pick an option from the menu.");
            }
             
         }  
     }
           for(int i = 0; i < locations.length; i++){
               if(player.location.items.size() >= 9){
                   endGame(true);
               }  
             } 
    }while(player.energy > 0);
   
    endGame(false);

}    
    
    public void endGame(boolean won){
      String playAgainChoice; 
      Scanner scan = new Scanner(System.in);
      
      if(won)
      {
          System.out.println("");
          System.out.println("Victory!");          
      }else
      {
          System.out.println("");
          System.out.println("You Lost!");       
      }
      
      System.out.println("Do you want to play again? (y/n)");
      playAgainChoice = scan.nextLine();
      
      if (playAgainChoice.charAt(0) == 'y')
      {   
          player.energy = 10;
          world();
          mainLoop();
          
      }else{
          System.out.println("Thanks for Playing!");
      }  
    }
    
}
