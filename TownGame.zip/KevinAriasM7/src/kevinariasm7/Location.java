/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kevinariasm7;

/**
 *
 * @author Admin
 */
import java.util.ArrayList;
public class Location {
    
    
public String name;
public String description;
public ArrayList<Item> items = new ArrayList<>();
public ArrayList<Location> adjacentLocations = new ArrayList<>();
public int itemsNum;
public int adjacentLocationsNum;
   
public Location(){
    
}    

public Location(String name, String description, int itemsNum, int adjacentLocationsNum){
    this.name = name;
    this.description = description;
    this.itemsNum = itemsNum;
    this.adjacentLocationsNum = adjacentLocationsNum;
}
    
public void display(){
    System.out.println(name);
    System.out.println(description);
    System.out.println(itemsNum + " Items that you can collect here.");
    System.out.println("You could travel to " + adjacentLocationsNum + " towns.");
    System.out.println("********************************************************");
    System.out.println("These are the items in this location.");
    for(int i = 0; i <items.size(); i++){
       System.out.println(items.get(i).itemName);
    }
    System.out.println("");
    System.out.println("You can go Here.");
    for(int i = 0; i < adjacentLocations.size(); i++){
       System.out.println(adjacentLocations.get(i).name);
    }
    System.out.println("");
    System.out.println("Select an option to do.");
    System.out.println("1. To move to another town");
    System.out.println("2. To pick up items.");
    System.out.println("3. To Drop your Items");
       
}
    
    
}
