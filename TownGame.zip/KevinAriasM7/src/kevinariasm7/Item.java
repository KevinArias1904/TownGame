/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kevinariasm7;

/**
 *
 * @author Admin
 */
public class Item {
    
  public String itemName;
  public String description;
      
public Item(String itemName, String description){
    this.itemName = itemName;
    this.description = description;
}

public String getItemName(){
    return itemName;
}
public String getItemDescription(){
    return description;
}    

}
